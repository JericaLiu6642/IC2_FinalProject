#include"game.h"
using namespace std;

int main()
{
	game myRPG;
	myRPG.run();
	return 0;
}
#pragma once
#ifndef WAND_H
#define WAND_H
#include <string>
#include"WeaponItem.h"

class Wand : public WeaponItem
{
public:
	Wand();
};

#endif // !AXE_H


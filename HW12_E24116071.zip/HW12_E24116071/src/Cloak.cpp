#include <iostream>
#include <string>
#include "Cloak.h"
using namespace std;

Cloak::Cloak()
	:ArmorItem(8, "Cloak_of_Invisibility", "defense + 100", 
		"The Cloak of Invisibility was a magical artefact used to render the wearer invisible.", 1, 'a', 100)
{

}